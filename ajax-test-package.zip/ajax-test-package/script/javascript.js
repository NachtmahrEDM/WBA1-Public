function test() {
    'use strict';
    alert("Javascript ist aktiviert!");
}

function getMore() {
    'use strict';
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (xhttp.readyState == 4 && xhttp.status == 200) {
            document.getElementById("contents").innerHTML = xhttp.responseText;
        }
    }
    
    xhttp.open("GET", "/ajax-test-package/script/text.txt", true);
    xhttp.send();
}